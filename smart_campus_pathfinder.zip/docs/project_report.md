# SMART CAMPUS PATHFINDER — INTELLIGENT CAMPUS NAVIGATION USING DSA
## A College Mini-Project Report in Data Structures and Algorithms (DSA)

---

### SECTION 1: TITLE PAGE

* **Project Title:** Smart Campus PathFinder — Intelligent Campus Navigation Using DSA
* **Domain:** Data Structures, Graph Theory, and Web Engineering
* **Programming Language:** Python 3 (Streamlit, NetworkX, Plotly, SQLite, pytest)
* **Academic Level:** Diploma / Undergraduate Computer Science & Engineering
* **Academic Year:** 2026–2027

---

### SECTION 2: CERTIFICATE TEMPLATE

```text
========================================================================================
                          DEPARTMENT OF COMPUTER SCIENCE & ENGINEERING
                                   COLLEGE OF ENGINEERING
                                        CERTIFICATE
========================================================================================

This is to certify that the project entitled:

             "SMART CAMPUS PATHFINDER — INTELLIGENT CAMPUS NAVIGATION USING DSA"

is a bonafide record of work carried out by the student(s) under my supervision in
partial fulfillment of the requirements for the award of the Degree / Diploma in
Computer Science & Engineering.

Date: _______________
Place: ______________

______________________                                       ______________________
Project Guide / Mentor                                        Head of Department
Assistant Professor, CSE                                      Department of CSE
========================================================================================
```

---

### SECTION 3: ACKNOWLEDGEMENT

We express our sincere gratitude to our Project Guide, whose constant mentorship, technical insights, and valuable guidance steered this mini-project to successful completion. We also thank the Head of the Department and the faculty members of the Computer Science and Engineering Department for providing the computational resources and software testing facilities required for developing this application. Finally, we thank our peers and families for their enduring encouragement.

---

### SECTION 4: ABSTRACT

Navigating extensive university campuses comprising academic blocks, research laboratories, libraries, auditoriums, canteens, hostels, and sports arenas presents everyday challenges for newly admitted students, visiting scholars, parents, and administrative staff. Conventional static signage and campus brochure maps lack real-time adaptability when campus walkways are closed due to construction, maintenance, or university fests.

**Smart Campus PathFinder** is an intelligent, graph-theoretic campus navigation application implemented in Python. The system represents campus landmarks as vertices and interconnecting walkways as weighted, bidirectional edges within an in-memory **Adjacency List**. The core pathfinding engine implements **Dijkstra’s Algorithm** with a binary min-heap (`heapq`) to calculate the mathematically minimal physical walking route in meters ($O((V+E)\log V)$). In addition, **Breadth-First Search (BFS)** ($O(V+E)$) is provided for pedagogical comparison, demonstrating how minimizing edge hops diverges from minimizing physical distance. The application features dynamic pathway blocking with real-time alternative route recalculation, persistent SQLite storage, interactive 2D graph mapping via NetworkX and Plotly, and an intuitive Streamlit interface. The system has been validated through 23 automated unit and integration tests under pytest.

---

### SECTION 5: INTRODUCTION

Data Structures and Algorithms (DSA) form the theoretical cornerstone of modern computer science. While abstract implementations on numeric arrays are common in laboratory curricula, applying graph theory to physical spatial navigation provides students and instructors with tangible, practical problem-solving experience.

A physical college campus can be naturally modeled as a **weighted, undirected graph**. Landmarks such as the Main Gate, Central Library, Administrative Block, and Computer Science Laboratories function as nodes. Paved walking pathways connecting these landmarks constitute edges, weighted by their measured walking distance in meters. 

By applying Dijkstra's shortest-path algorithm and Breadth-First Search over a clean web interface, this project bridges theoretical algorithm design with practical software engineering.

---

### SECTION 6: PROBLEM STATEMENT

Modern educational campuses often span tens of acres with numerous interconnected walking trails, courtyards, and bypasses. Visitors and new students face several key navigational problems:
1. **Inefficient Navigation:** Walking longer distances due to lack of familiarity with shortcuts and optimal pathways.
2. **Pathway Disruption:** Temporary pathway closures (e.g., building renovations, convocation barricades, monsoon waterlogging) render standard routes impassable without clear detour guidance.
3. **Static Signage Inadequacy:** Physical campus signboards do not provide turn-by-turn distance estimates or cumulative walking times.
4. **Lack of Educational Demonstration:** University curricula often lack working, interactive software demonstrating how priority-queue-based Dijkstra and queue-based BFS behave differently under real-world weights.

---

### SECTION 7: OBJECTIVES

1. Model the university campus as an undirected, weighted graph using an **Adjacency List**.
2. Implement **Dijkstra’s algorithm** using Python’s native binary min-heap (`heapq`) to compute minimal physical walking distance.
3. Implement **Breadth-First Search (BFS)** using `collections.deque` to find routes with the fewest number of turns/edges.
4. Provide a dynamic **alternative route finder** that bypasses blocked paths in both directions in $O(1)$ lookup time.
5. Provide administrative tools to add, edit, or delete campus locations and pathways with input validation.
6. Persist campus nodes, edges, blocked statuses, and audit search histories using **SQLite**.
7. Render an interactive, 2D campus network visualization using **NetworkX** and **Plotly**.
8. Achieve 100% test pass rate across unit and integration tests using **pytest**.

---

### SECTION 8: LITERATURE REVIEW

1. **Dijkstra, E. W. (1959):** *"A note on two problems in connexion with graphs."* Numerische Mathematik. Established the single-source shortest path algorithm on graphs with non-negative edge weights.
2. **Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. (2022):** *Introduction to Algorithms (4th ed.).* MIT Press. Details graph representations, min-heap priority queues, and asymptotic complexity analysis of Dijkstra ($O((V+E)\log V)$) versus BFS ($O(V+E)$).
3. **Goldberg, A. V., & Harrelson, C. (2005):** *Computing the Shortest Path: A Search Meets Graph Theory.* Examined heuristics and bidirectional search for road networks.
4. **Russell, S., & Norvig, P. (2020):** *Artificial Intelligence: A Modern Approach.* Outlines state-space search, informed vs. uninformed search strategies, and routing optimizations.

---

### SECTION 9: EXISTING SYSTEM

Conventional campus navigation relies on:
- **Physical Campus Signposts:** Prone to physical wear, static, and cannot show real-time closures.
- **Printed Brochures & PDF Maps:** Lack interactivity, distance calculations, and step-by-step guidance.
- **Commercial Map Providers (e.g., Google Maps):** Often do not map internal pedestrian walkways, courtyard shortcuts, or university building interior wings. They also require paid API credentials and constant internet connectivity.

---

### SECTION 10: PROPOSED SYSTEM

The **Smart Campus PathFinder** offers:
- Completely offline and local execution using pure Python and standard libraries.
- Accurate modeling of designated pedestrian walking trails with calibrated distances in meters.
- Instant recalculation of alternative routes when pathways are blocked by administrators.
- Side-by-side pedagogical comparison of Dijkstra's algorithm vs. BFS.
- Turn-by-turn walking cards with cumulative time estimates based on configurable walking speed.
- Full CRUD management backed by SQLite transactions.

---

### SECTION 11: REQUIREMENT ANALYSIS

#### Functional Requirements
1. The user must be able to select any source and destination from a dropdown list.
2. The system must compute and display the shortest route, total distance in meters, and estimated walking time.
3. Identical source and destination inputs must return 0 meters immediately.
4. Unreachable locations must trigger clear warning diagnostics.
5. Administrators must be able to block/unblock pathways with instant visual updates.
6. The system must support full CRUD operations for locations and connections.
7. Route queries must be logged into persistent search history.

#### Non-Functional Requirements
1. **Performance:** Route computation must execute in under 1 millisecond ($< 1000\ \mu\text{s}$) for typical campus graphs.
2. **Reliability:** ACID compliant SQLite operations with foreign key integrity.
3. **Usability:** Responsive, professional blue-and-white theme accessible on desktop and mobile browsers.
4. **Maintainability:** Modular separation between graph logic, database access, algorithms, and visualization.

---

### SECTION 12: HARDWARE AND SOFTWARE REQUIREMENTS

#### Software Requirements
* **Operating System:** Windows 10/11, Linux (Ubuntu/Debian), or macOS
* **Runtime Environment:** Python 3.10 to 3.13
* **Web Framework:** Streamlit $\ge 1.35.0$
* **Graph & Visualization Libraries:** NetworkX $\ge 3.0$, Plotly $\ge 5.18.0$
* **Data Processing:** Pandas $\ge 2.0.0$
* **Database:** SQLite 3 (Built into Python)
* **Testing Tool:** pytest $\ge 8.0.0$

#### Minimum Hardware Requirements
* **Processor:** Intel Core i3 / AMD Ryzen 3 or equivalent
* **RAM:** 4 GB minimum (8 GB recommended)
* **Disk Space:** 250 MB free space

---

### SECTION 13: SYSTEM ARCHITECTURE

```text
+-------------------------------------------------------------------------+
|                       PRESENTATION LAYER (UI/UX)                        |
|                                                                         |
|      Streamlit Web Interface (app.py)   <--->   Plotly Maps (viz.py)    |
+------------------------------------+------------------------------------+
                                     |
                                     v
+-------------------------------------------------------------------------+
|                      APPLICATION SERVICE LAYER                          |
|                                                                         |
|                    CampusService (campus_service.py)                     |
|            - Coordinates in-memory graph with persistent DB             |
|            - Computes turn directions and estimated times               |
+--------------------+-------------------------------+--------------------+
                     |                               |
                     v                               v
+-----------------------------+     +-------------------------------------+
|        DSA CORE LAYER       |     |          PERSISTENCE LAYER          |
|                             |     |                                     |
|  CampusGraph (graph.py)     |     |   CampusDatabase (database.py)      |
|  - Adjacency List           |     |   - SQLite3 Database (campus.db)    |
|  - Blocked Edge Hash Set    |     |   - locations table                 |
|                             |     |   - connections table               |
|  Algorithms (algorithms.py) |     |   - search_history table            |
|  - Dijkstra (heapq)         |     |   - Parameterized SQL & Transactions|
|  - BFS (collections.deque)  |     +-------------------------------------+
|  - Path Reconstructor       |
+-----------------------------+
```

---

### SECTION 14: DSA CONCEPTS USED

1. **Adjacency List:** A dictionary of dictionaries `Dict[str, Dict[str, float]]` mapping vertex $u$ to neighbors $v$ with distance weight $w$. Space complexity $O(V + E)$.
2. **Binary Min-Heap Priority Queue (`heapq`):** Maintains frontier nodes ordered by minimum tentative distance. Enables $O(\log V)$ insertions and extractions.
3. **FIFO Queue (`collections.deque`):** Double-ended queue used in BFS to explore graph levels in first-in, first-out order in $O(1)$ push/pop time.
4. **Hash Table (`set` & `dict`):** Used for canonical blocked edges set, visited node tracking, and predecessor tracking with $O(1)$ average lookup time.
5. **Path Backtracking:** Starts from destination vertex and sequentially traces through predecessor map back to the starting vertex in $O(V)$ time.

---

### SECTION 15: ALGORITHM DESIGN AND PSEUDOCODE

#### Dijkstra's Algorithm (Min-Heap Implementation)
```text
Algorithm Dijkstra(Graph, Start, Destination, IncludeBlocked):
    Input: Graph G = (V, E), Start node s, Destination node d
    Output: Shortest distance, ordered path list, and statistics

    1. If s == d:
           Return path = [s], distance = 0.0

    2. Initialize distances[v] = infinity for all v in V
    3. Initialize predecessors[v] = None for all v in V
    4. Set distances[s] = 0.0

    5. Initialize Priority Queue PQ = [(0.0, s)]
    6. Initialize visited = empty set

    7. While PQ is not empty:
           Pop (current_dist, u) with smallest distance from PQ
           
           If current_dist > distances[u]:
               Continue (Lazy deletion optimization)
               
           Add u to visited
           
           If u == d:
               Break (Early exit optimization)
               
           For each (v, weight) in Graph.get_neighbors(u, IncludeBlocked):
               If v in visited:
                   Continue
               
               new_dist = current_dist + weight
               If new_dist < distances[v]:
                   distances[v] = new_dist
                   predecessors[v] = u
                   Push (new_dist, v) into PQ

    8. If distances[d] == infinity:
           Return Unreachable (found = False)

    9. Reconstruct path by backtracking predecessors from d to s
    10. Return path, distances[d], edges_count
```

#### Breadth-First Search (BFS)
```text
Algorithm BFS_Fewest_Hops(Graph, Start, Destination, IncludeBlocked):
    Input: Graph G = (V, E), Start node s, Destination node d
    Output: Minimum edge path list, total distance

    1. If s == d: Return path = [s], distance = 0.0
    2. Initialize Queue Q = [s]
    3. Initialize visited = {s}
    4. Initialize predecessors = {s: None}

    5. While Q is not empty:
           current = Q.pop_left()
           If current == d:
               Break
           For each v in Graph.get_neighbors(current, IncludeBlocked):
               If v not in visited:
                   Add v to visited
                   predecessors[v] = current
                   Q.append(v)

    6. Reconstruct path from d to s using predecessors
    7. Calculate physical distance along reconstructed path
    8. Return path, distance, edge_count
```

---

### SECTION 16: SYSTEM FLOWCHART

```mermaid
flowchart TD
    A([Start: User Selects Source & Destination]) --> B{Source == Destination?}
    B -- Yes --> C[Return Distance = 0m, Path = Source]
    B -- No --> D[Initialize Dijkstra Min-Heap with Source]
    D --> E{Min-Heap Empty?}
    E -- Yes --> F[Destination Unreachable: Return Warning]
    E -- No --> G[Pop Node with Smallest Tentative Distance]
    G --> H{Node == Destination?}
    H -- Yes --> I[Backtrack Predecessors to Build Path]
    H -- No --> J[Iterate Over Unblocked Neighbors]
    J --> K{New Distance < Recorded Distance?}
    K -- Yes --> L[Update Distance, Set Predecessor, Push to Heap]
    K -- No --> J
    L --> E
    I --> M[Calculate Turn Times & Distance]
    M --> N[Highlight Route on Plotly 2D Map]
    N --> O[Log Query in SQLite Database]
    O --> P([End: Render Results to User])
    F --> P
    C --> P
```

---

### SECTION 17: DATABASE DESIGN

#### Relational Schema Overview
The persistent SQLite database schema utilizes three normalized tables:

1. **`locations` Table:**
   - `id`: INTEGER PRIMARY KEY AUTOINCREMENT
   - `name`: TEXT UNIQUE NOT NULL
   - `category`: TEXT NOT NULL DEFAULT 'Academic'
   - `x`: REAL NOT NULL (Grid X coordinate, 0–100)
   - `y`: REAL NOT NULL (Grid Y coordinate, 0–100)
   - `description`: TEXT
   - `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

2. **`connections` Table:**
   - `id`: INTEGER PRIMARY KEY AUTOINCREMENT
   - `source_name`: TEXT NOT NULL (Foreign Key $\rightarrow$ `locations(name)`)
   - `destination_name`: TEXT NOT NULL (Foreign Key $\rightarrow$ `locations(name)`)
   - `distance`: REAL NOT NULL CHECK(distance > 0)
   - `is_blocked`: INTEGER NOT NULL DEFAULT 0 CHECK(is_blocked IN (0, 1))
   - `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   - `UNIQUE(source_name, destination_name)`

3. **`search_history` Table:**
   - `id`: INTEGER PRIMARY KEY AUTOINCREMENT
   - `start_location`: TEXT NOT NULL
   - `destination_location`: TEXT NOT NULL
   - `algorithm`: TEXT NOT NULL
   - `distance`: REAL NOT NULL
   - `edges_count`: INTEGER NOT NULL
   - `path_taken`: TEXT NOT NULL
   - `execution_time_us`: REAL DEFAULT 0.0
   - `searched_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

---

### SECTION 18: MODULE DESCRIPTION

1. **`config.py`:** Application configuration, database paths, walking speed constants (80 m/min), and category color palettes.
2. **`graph.py`:** `CampusGraph` class encapsulating the Adjacency List, node addition/deletion, edge creation, validation checks, and $O(1)$ blocked edge hash set.
3. **`algorithms.py`:** Pure implementation of Dijkstra's algorithm (`heapq`), BFS (`collections.deque`), path reconstruction, step-by-step guidance generation, and comparative benchmarking.
4. **`database.py`:** `CampusDatabase` class managing SQLite connections, parameterized queries, schema creation, data seeding, and transactions.
5. **`campus_service.py`:** Business logic orchestrator synchronizing in-memory graph state with SQLite persistence.
6. **`visualization.py`:** NetworkX and Plotly rendering engine generating responsive 2D graph figures with custom styling and tooltips.
7. **`app.py`:** Streamlit interactive presentation frontend containing the 9 operational modules.

---

### SECTION 19: IMPLEMENTATION DETAILS

* **Zero Third-Party Routing Dependency:** The core routing algorithms are written manually using Python's built-in `heapq` and `collections.deque` modules.
* **Canonical Undirected Edge Storage:** Both database and memory represent undirected edges in canonical alphabetical order (`(min(u, v), max(u, v))`) ensuring bidirectional consistency.
* **Parameterized Query Execution:** All SQL operations utilize parameterized statements to eliminate SQL injection vulnerabilities.
* **Turn-by-Turn Guidance:** Each segment calculates realistic walking time based on a standard pedestrian walking speed of 80 meters/minute (4.8 km/h).

---

### SECTION 20: APPLICATION USER INTERFACE WALKTHROUGH

The application interface is structured into 9 dedicated modules:
1. **Dashboard:** Displays metric summary cards for total locations, connections, blocked pathways, and available paths; live 2D campus map; recent queries table.
2. **Find Shortest Route:** Dropdowns to select source and destination, walking speed slider, breadcrumb path ribbon, Plotly highlighted map, and step-by-step turn cards.
3. **Interactive Campus Map:** Interactive 2D spatial plot with hover tooltips and category-filtered location directory.
4. **Compare Algorithms (Dijkstra vs BFS):** Side-by-side comparative analysis of physical distance vs. edge hop minimization.
5. **Manage Locations:** Forms to add new campus buildings, update existing details, or delete locations safely.
6. **Manage Connections:** Forms to connect landmarks with measured distances, modify lengths, or delete connections.
7. **Blocked Paths & Detours:** Quick toggles to simulate campus walkway closures and test automatic detour recalculations.
8. **Route Search History:** Log table of recent searches with CSV download option.
9. **About the Project & DSA:** In-depth documentation of graph theory concepts, complexities, and project architecture.

---

### SECTION 21: TEST CASES AND ACTUAL TEST RESULTS

All 23 automated tests were executed using `pytest` on Python 3.13. All 23 tests passed successfully.

| Test ID | Module | Test Function | Purpose / Scenario | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC01** | `test_algorithms` | `test_dijkstra_known_shortest_path` | Verifies shortest path on sample graph (Main Gate $\rightarrow$ Library = 250m) | **PASSED** |
| **TC02** | `test_algorithms` | `test_source_equals_destination` | Verifies base case when start equals destination (distance = 0.0m) | **PASSED** |
| **TC03** | `test_algorithms` | `test_unreachable_destination` | Verifies handling of disconnected isolated node | **PASSED** |
| **TC04** | `test_algorithms` | `test_invalid_missing_location` | Verifies error raised for non-existent node | **PASSED** |
| **TC05** | `test_algorithms` | `test_blocked_connection_and_alternative_route` | Verifies detour calculation when intermediate edge is blocked | **PASSED** |
| **TC06** | `test_algorithms` | `test_bfs_vs_dijkstra_difference` | Validates divergence: BFS chooses fewer hops (1 hop, 260m) while Dijkstra chooses shorter distance (2 hops, 250m) | **PASSED** |
| **TC07** | `test_campus_service`| `test_service_initialization_and_seeding` | Verifies automatic sample dataset initialization | **PASSED** |
| **TC08** | `test_campus_service`| `test_find_shortest_route_with_instructions` | Verifies turn-by-turn guidance and time calculation | **PASSED** |
| **TC09** | `test_campus_service`| `test_route_updates_after_blocking_connection` | Verifies active route bypasses blocked pathways | **PASSED** |
| **TC10** | `test_campus_service`| `test_dynamic_graph_mutation_affects_routing` | Verifies shortcut addition and deletion dynamically affects routing | **PASSED** |
| **TC11** | `test_campus_service`| `test_dashboard_metrics` | Verifies dashboard count accuracy | **PASSED** |
| **TC12** | `test_database` | `test_db_initialization` | Verifies table schema creation | **PASSED** |
| **TC13** | `test_database` | `test_location_crud_and_persistence` | Verifies location CRUD and persistence across reopened connections | **PASSED** |
| **TC14** | `test_database` | `test_connection_constraints_and_validation` | Verifies positive distance checks, self-loop prevention, foreign key validation | **PASSED** |
| **TC15** | `test_database` | `test_connection_blocking_and_updates` | Verifies connection distance updates and blocked state persistence | **PASSED** |
| **TC16** | `test_database` | `test_seed_sample_campus` | Verifies sample dataset seeding with 10 locations and $\ge 15$ edges | **PASSED** |
| **TC17** | `test_database` | `test_search_history_logging` | Verifies search query logging and history clearing | **PASSED** |
| **TC18** | `test_graph` | `test_add_and_get_nodes` | Verifies node insertion and metadata retrieval | **PASSED** |
| **TC19** | `test_graph` | `test_node_validation_duplicate_and_empty` | Verifies rejection of empty names and duplicate locations | **PASSED** |
| **TC20** | `test_graph` | `test_add_edge_and_get_neighbors` | Verifies bidirectional adjacency list neighbor mapping | **PASSED** |
| **TC21** | `test_graph` | `test_edge_validations` | Verifies rejection of negative distances and duplicate edges | **PASSED** |
| **TC22** | `test_graph` | `test_remove_node_cascades_to_edges` | Verifies deleting node removes incident edges in memory | **PASSED** |
| **TC23** | `test_graph` | `test_blocked_edge_handling` | Verifies $O(1)$ canonical blocked edge hash set toggling | **PASSED** |

---

### SECTION 22: TIME AND SPACE COMPLEXITY ANALYSIS

| Algorithm / Operation | Primary Data Structure | Time Complexity | Auxiliary Space Complexity |
| :--- | :--- | :--- | :--- |
| **Dijkstra's Shortest Path** | Binary Min-Heap (`heapq`) | $O((V + E) \log V)$ | $O(V + E)$ |
| **Breadth-First Search (BFS)** | FIFO Queue (`deque`) | $O(V + E)$ | $O(V)$ |
| **Graph Adjacency List** | Dictionary of Dictionaries | $O(1)$ neighbor lookup | $O(V + E)$ |
| **Blocked Edge Query** | Canonical Hash Set | $O(1)$ average | $O(E_{blocked})$ |
| **Path Reconstruction** | Hash Map Backtracking | $O(V)$ | $O(V)$ |
| **Location Addition / Deletion** | Hash Map + SQLite INSERT | $O(1)$ memory + $O(1)$ I/O | $O(1)$ |

---

### SECTION 23: RESULTS AND DISCUSSION

1. **Algorithm Correctness:** Dijkstra's algorithm consistently discovers the optimal physical walking path. On benchmark test graphs, Dijkstra runs in under $150\ \mu\text{s}$ ($0.00015\text{ seconds}$), providing instantaneous UI responsiveness.
2. **Pedagogical Value:** The project clearly demonstrates why BFS is unsuitable for weighted spatial networks. On the route from `Admin Block` to `Campus Canteen`, BFS selects the single-hop 260m path, whereas Dijkstra selects the two-hop 250m path via the Central Library, saving 10 meters of walking distance.
3. **Resilience to Pathway Closures:** Toggling any pathway to "Blocked" immediately triggers the routing engine to discover the next shortest detour without requiring application restart.

---

### SECTION 24: ADVANTAGES AND LIMITATIONS

#### Advantages
* **Completely Offline:** Runs locally without paid API keys, internet dependencies, or cloud subscription fees.
* **Strict DSA Rigor:** Implements algorithms manually without black-box routing libraries.
* **Persistent Data Store:** SQLite preserves all campus modifications and search records.
* **Interactive Visualization:** Plotly maps enable intuitive zoom, pan, hover, and route highlights.

#### Limitations
* **2D Grid Simplification:** Assumes all campus walkways are on a planar ground surface; multi-story elevation changes (elevators, staircases) are modeled via equivalent flat walking distances.
* **Static Walking Speed:** Walking speed is estimated based on an average pedestrian velocity (80 m/min) rather than real-time GPS tracking.

---

### SECTION 25: FUTURE SCOPE

1. **3D Multi-Floor Indoor Navigation:** Extending nodes to include floor levels ($Z$-axis) with staircase and elevator transitions.
2. **Accessibility-Focused Routing:** Introducing slope and staircase weight penalties to provide wheelchair-accessible routes.
3. **Mobile GPS Integration:** Synchronizing client GPS coordinates to show real-time user location markers on the interactive campus map.
4. **Time-Dependent Dynamic Weights:** Automatically increasing edge weights during peak class transition intervals to simulate pedestrian crowding.

---

### SECTION 26: CONCLUSION

The **Smart Campus PathFinder** project demonstrates the effective application of fundamental Data Structures and Algorithms to practical campus navigation. By combining a weighted graph representation, an efficient min-heap implementation of Dijkstra’s algorithm, dynamic pathway closure handling, persistent SQLite storage, and a modern Streamlit interface, the project satisfies all core academic and functional criteria. The automated test suite validates the system's correctness and resilience, making it an exemplary DSA college mini-project.

---

### SECTION 27: REFERENCES

1. Dijkstra, E. W. (1959). *A note on two problems in connexion with graphs.* Numerische Mathematik, 1(1), 269–271.
2. Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. (2022). *Introduction to Algorithms* (4th ed.). MIT Press.
3. Streamlit Documentation: https://docs.streamlit.io/
4. NetworkX Developer Guide: https://networkx.org/documentation/stable/
5. Plotly Open Source Graphing Library for Python: https://plotly.com/python/
6. Python Standard Library Documentation (`heapq`, `collections.deque`, `sqlite3`): https://docs.python.org/3/

---

### SECTION 28: VIVA QUESTIONS AND ANSWERS SUMMARY

*(See companion document [`docs/viva_questions.md`](viva_questions.md) for full question-and-answer preparation guide).*
* **Core Topic 1:** Adjacency List $O(V + E)$ space vs. Adjacency Matrix $O(V^2)$.
* **Core Topic 2:** Dijkstra greedy strategy, non-negative weights constraint, and min-heap $O((V+E)\log V)$ complexity.
* **Core Topic 3:** Difference between BFS (minimum edge hops) and Dijkstra (minimum accumulated distance).
* **Core Topic 4:** SQLite ACID compliance, parameterized queries, and foreign key cascading.
* **Core Topic 5:** Blocked edge handling using canonical tuple hash sets in $O(1)$ time.
