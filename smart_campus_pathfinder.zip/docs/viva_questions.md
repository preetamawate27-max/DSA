# Smart Campus PathFinder — Viva Examination Questions & Answers

This document provides a comprehensive preparation guide for college oral examinations (Viva Voce), technical project defense, and algorithmic interviews on the **Smart Campus PathFinder** project.

---

## Category 1: Graph Theory & Data Structures

### Q1: What is a Graph, and how is it used in this project?
**Answer:** A graph $G = (V, E)$ is a non-linear data structure consisting of a set of vertices (or nodes) $V$ and a set of edges $E$ that connect pairs of vertices. In this project:
- **Vertices ($V$):** Represent campus landmarks and locations (e.g., Main Gate, Admin Block, Central Library, Computer Science Lab).
- **Edges ($E$):** Represent designated walking pathways connecting two locations.
- **Weights ($W$):** Represent the physical walking distance in meters between two connected locations.

---

### Q2: Why did you choose an Adjacency List over an Adjacency Matrix?
**Answer:** 
1. **Space Efficiency:** An Adjacency Matrix requires $O(V^2)$ memory space regardless of the number of edges. A campus walking map is a **sparse graph** (each location is connected to only 2–4 neighboring pathways, so $E \ll V^2$). An Adjacency List requires only $O(V + E)$ memory space.
2. **Time Efficiency for Neighborhood Traversal:** In an adjacency list, finding all neighbors of a node takes $O(\text{degree}(v))$ time. In an adjacency matrix, scanning row $v$ to find neighbors takes $O(V)$ time even if there is only one neighbor.

---

### Q3: Is the campus graph directed or undirected?
**Answer:** The campus graph is **undirected** (bidirectional). When a walkway exists between Location A and Location B, pedestrians can travel in both directions ($A \rightarrow B$ and $B \rightarrow A$) with equal physical distance. In our adjacency list, if edge $(u, v)$ with weight $w$ is added, it is stored in both `adj[u][v] = w` and `adj[v][u] = w`.

---

### Q4: How are blocked pathways modeled and checked in constant time?
**Answer:** We maintain a `blocked_edges` set storing canonical undirected tuples `(min(u, v), max(u, v))`. Because Python sets are implemented as hash tables, checking whether a path between $u$ and $v$ is blocked requires $O(1)$ average time complexity. When calculating paths, neighbors connected via blocked edges are filtered out.

---

## Category 2: Dijkstra's Shortest Path Algorithm

### Q5: What is Dijkstra's algorithm, and what is its objective?
**Answer:** Dijkstra's algorithm is a greedy graph search algorithm that finds the shortest path between a source vertex and all other vertices (single-source shortest path) in a graph with non-negative edge weights. In our project, it determines the minimum physical walking distance in meters between a student's starting point and destination.

---

### Q6: Why must edge weights in Dijkstra's algorithm be non-negative?
**Answer:** Dijkstra relies on the greedy property: once a node is extracted from the priority queue with minimal distance, its shortest distance from the source is finalized and will never decrease. If negative edge weights were allowed, traversing an edge could reduce the total accumulated distance, invalidating the greedy assumption. Walking distances on a campus are physical lengths ($> 0$), which satisfies this constraint.

---

### Q7: Why did you implement Dijkstra using a Min-Heap (`heapq`) rather than a linear array?
**Answer:** 
- With a linear array / unsorted list: finding the vertex with minimum distance takes $O(V)$ time. Across $V$ vertices, this requires $O(V^2)$ time.
- With a binary min-heap (`heapq`): extracting the minimum element (`heappop`) takes $O(\log V)$, and inserting or updating distance (`heappush`) takes $O(\log V)$. For a sparse graph where $E \approx V$, this reduces the overall time complexity from $O(V^2)$ to $O((V + E) \log V)$.

---

### Q8: What is "Lazy Deletion" in your min-heap implementation?
**Answer:** Python's standard `heapq` module does not natively support a `decrease-key` operation in $O(\log V)$ without complex pointer indexing. Instead, when a shorter distance to a node is discovered, we push a new tuple `(new_distance, node)` onto the heap. When extracting elements, if the popped distance is greater than the recorded distance in our `distances` dictionary (`dist > distances[current_node]`), we simply skip it. This achieves the same asymptotic complexity without modifying internal heap pointers.

---

### Q9: How is the shortest path reconstructed from the destination back to the source?
**Answer:** We maintain a `predecessors` dictionary (mapping each node to the previous node that relaxed its distance). When the destination is reached:
1. Start at `destination` and backtrack: `current = predecessors[current]`.
2. Append each visited predecessor until reaching `start`.
3. Reverse the accumulated list to obtain the chronological route `[start, ..., destination]`. Path reconstruction takes $O(V)$ time.

---

## Category 3: Breadth-First Search (BFS) vs. Dijkstra

### Q10: What is the difference between BFS and Dijkstra's algorithm?
**Answer:** 
- **BFS (Breadth-First Search):** Explores vertices level-by-level using a FIFO queue (`collections.deque`). It assumes all edges have uniform weight ($1$) and finds the path with the **fewest number of edges (hops)**.
- **Dijkstra's Algorithm:** Uses a priority queue (`heapq`) to explore edges based on accumulated numerical weight. It finds the path with the **minimum physical walking distance in meters**.

---

### Q11: Can BFS find the shortest physical distance on a weighted graph? Give an example.
**Answer:** No. BFS does not take edge weights into account.
**Example from our campus dataset:**
- Path 1: `Admin Block` $\rightarrow$ `Campus Canteen` (Direct: 1 edge, distance = **260 meters**).
- Path 2: `Admin Block` $\rightarrow$ `Central Library` (140m) $\rightarrow$ `Campus Canteen` (110m) (2 edges, total distance = **250 meters**).
- BFS chooses **Path 1** because it has only 1 hop (260m).
- Dijkstra chooses **Path 2** because $250\text{ m} < 260\text{ m}$.

---

### Q12: What is the time and space complexity of BFS?
**Answer:** 
- **Time Complexity:** $O(V + E)$, because each vertex is enqueued at most once and each incident edge is traversed once.
- **Space Complexity:** $O(V)$ for the queue, visited set, and predecessor dictionary.

---

## Category 4: Software Architecture & Database

### Q13: Describe the three-tier architectural separation in this project.
**Answer:**
1. **Presentation Layer (`app.py` & `visualization.py`):** Streamlit web application and Plotly interactive 2D graph renderings.
2. **Business / Service Layer (`campus_service.py`, `graph.py`, `algorithms.py`):** Pure Python graph data structure, Dijkstra and BFS algorithms, validation rules, turn-by-turn guidance, and walking time calculations.
3. **Persistence Layer (`database.py`):** SQLite database storing locations, pathways, blocked states, and search history using parameterized SQL queries and foreign keys.

---

### Q14: Why keep an in-memory graph if the data is already stored in SQLite?
**Answer:** Database disk I/O and SQL queries are substantially slower than in-memory pointer lookups. Storing the active graph in RAM allows Dijkstra's algorithm to execute in **microseconds** ($< 200\ \mu\text{s}$). SQLite is used strictly for persistence across application restarts and auditing search history.

---

### Q15: How do you prevent SQL injection in your database layer?
**Answer:** We never concatenate raw user input into SQL query strings. All queries strictly utilize **parameterized SQL statements** with `?` placeholders (e.g., `cursor.execute("SELECT * FROM locations WHERE name = ?", (name,))`), which separates SQL command logic from user-supplied data.

---

### Q16: How are cascading deletions handled when a location is deleted?
**Answer:** The SQLite `connections` table defines foreign keys with `ON DELETE CASCADE`:
```sql
FOREIGN KEY(source_name) REFERENCES locations(name) ON UPDATE CASCADE ON DELETE CASCADE
```
When a location is deleted, all incident pathways are automatically deleted by the database engine, and the in-memory graph removes incident edges to prevent orphaned references.

---

## Category 5: Edge Cases, Testing, and Error Handling

### Q17: How does the application handle a query where the source and destination are identical?
**Answer:** A base-case check detects `start == destination`. The algorithm immediately returns distance = `0.0` meters, edges = `0`, path = `[start]`, and execution time $< 10\ \mu\text{s}$ without running heap loops.

---

### Q18: What happens if the destination is disconnected or completely blocked off?
**Answer:** If the destination cannot be reached from the source, `distances[destination]` remains `float("inf")` after the priority queue is exhausted. The algorithm flags `found = False`, returns an empty path, and generates an informative user warning explaining that the destination is unreachable due to pathway closures.

---

### Q19: What validations are performed when adding a connection between two locations?
**Answer:**
1. Both locations must exist in the campus database.
2. The source and destination cannot be the same (no self-loops).
3. The distance must be strictly positive ($> 0\text{ m}$).
4. The connection cannot be a duplicate of an existing pathway in either direction.

---

### Q20: What automated tests were implemented, and what framework was used?
**Answer:** We wrote 23 automated unit and integration tests using `pytest` covering:
- Known shortest path verification on sample campus graphs.
- Source equal to destination base cases.
- Unreachable isolated landmarks.
- Blocked connection rerouting.
- BFS vs. Dijkstra divergence validation.
- Database persistence, CRUD operations, and constraints.
- Real-time graph updates reflecting in route outputs.

---

## Quick Reference Summary Table for Viva

| Algorithm / Component | Data Structure Used | Time Complexity | Space Complexity |
| :--- | :--- | :--- | :--- |
| **Dijkstra's Algorithm** | Binary Min-Heap (`heapq`) | $O((V + E) \log V)$ | $O(V + E)$ |
| **Breadth-First Search** | FIFO Queue (`deque`) | $O(V + E)$ | $O(V)$ |
| **Graph Representation** | Adjacency List (`dict` of `dict`) | $O(1)$ neighbor lookup | $O(V + E)$ |
| **Blocked Path Tracking** | Hash Set (`set`) | $O(1)$ membership check | $O(E_{blocked})$ |
| **Path Reconstruction** | Hash Map (`dict`) | $O(V)$ backtrack | $O(V)$ |
