"""
Unit tests for DSA algorithms module (Dijkstra's Algorithm and Breadth-First Search).
"""

import pytest
from graph import CampusGraph
from algorithms import dijkstra_shortest_path, bfs_shortest_hops, compare_algorithms


@pytest.fixture
def sample_graph():
    """Builds a test campus network with known weights."""
    g = CampusGraph()
    for name in ["Main Gate", "Admin Block", "Library", "Canteen", "Hostel", "Isolated"]:
        g.add_node(name)

    g.add_edge("Main Gate", "Admin Block", 100.0)
    g.add_edge("Admin Block", "Library", 150.0)
    g.add_edge("Library", "Canteen", 80.0)
    g.add_edge("Main Gate", "Library", 300.0)
    g.add_edge("Canteen", "Hostel", 120.0)
    # Notice: Isolated has no connections
    return g


def test_dijkstra_known_shortest_path(sample_graph):
    # Main Gate -> Library: direct is 300m, via Admin is 100 + 150 = 250m.
    res = dijkstra_shortest_path(sample_graph, "Main Gate", "Library")
    assert res["found"] is True
    assert res["path"] == ["Main Gate", "Admin Block", "Library"]
    assert res["total_distance"] == 250.0
    assert res["edges_count"] == 2


def test_source_equals_destination(sample_graph):
    res = dijkstra_shortest_path(sample_graph, "Admin Block", "Admin Block")
    assert res["found"] is True
    assert res["path"] == ["Admin Block"]
    assert res["total_distance"] == 0.0
    assert res["edges_count"] == 0


def test_unreachable_destination(sample_graph):
    res = dijkstra_shortest_path(sample_graph, "Main Gate", "Isolated")
    assert res["found"] is False
    assert res["path"] == []
    assert res["total_distance"] == float("inf")
    assert "unreachable" in res["message"].lower()


def test_invalid_missing_location(sample_graph):
    with pytest.raises(ValueError, match="not found in campus database"):
        dijkstra_shortest_path(sample_graph, "Ghost Location", "Library")

    with pytest.raises(ValueError, match="not found in campus database"):
        dijkstra_shortest_path(sample_graph, "Main Gate", "Ghost Location")


def test_blocked_connection_and_alternative_route(sample_graph):
    # Block Admin Block <-> Library
    sample_graph.set_edge_blocked("Admin Block", "Library", True)

    # Now shortest path Main Gate -> Library must bypass the blocked path and take direct 300m
    res = dijkstra_shortest_path(sample_graph, "Main Gate", "Library", include_blocked=False)
    assert res["found"] is True
    assert res["path"] == ["Main Gate", "Library"]
    assert res["total_distance"] == 300.0

    # If include_blocked is True, it would take the blocked 250m route
    res_blocked = dijkstra_shortest_path(sample_graph, "Main Gate", "Library", include_blocked=True)
    assert res_blocked["path"] == ["Main Gate", "Admin Block", "Library"]
    assert res_blocked["total_distance"] == 250.0


def test_bfs_vs_dijkstra_difference():
    """
    Constructs a graph where:
    Direct pathway has 1 hop but large weight (260m).
    Alternative pathway has 2 hops but smaller weight (140m + 110m = 250m).
    Dijkstra must pick [A, C, B] (250m).
    BFS must pick [A, B] (1 hop).
    """
    g = CampusGraph()
    g.add_node("A")
    g.add_node("B")
    g.add_node("C")

    g.add_edge("A", "B", 260.0)
    g.add_edge("A", "C", 140.0)
    g.add_edge("C", "B", 110.0)

    d_res = dijkstra_shortest_path(g, "A", "B")
    b_res = bfs_shortest_hops(g, "A", "B")

    # Dijkstra minimizes distance: 140 + 110 = 250 < 260
    assert d_res["path"] == ["A", "C", "B"]
    assert d_res["total_distance"] == 250.0
    assert d_res["edges_count"] == 2

    # BFS minimizes hops: direct edge has 1 hop
    assert b_res["path"] == ["A", "B"]
    assert b_res["total_distance"] == 260.0
    assert b_res["edges_count"] == 1

    # Verify compare_algorithms function
    comp = compare_algorithms(g, "A", "B")
    assert comp["same_path"] is False
    assert comp["distance_difference_meters"] == 10.0  # 260 - 250
    assert comp["hops_difference"] == -1              # 1 - 2
