"""
Integration tests for CampusService orchestrator.
Verifies end-to-end synchronization between database, graph, and routing engine.
"""

import pytest
from campus_service import CampusService


@pytest.fixture
def service(tmp_path):
    """Initializes CampusService with an isolated test SQLite DB."""
    db_file = tmp_path / "service_test.db"
    return CampusService(db_path=db_file)


def test_service_initialization_and_seeding(service):
    stats = service.graph.get_summary_stats()
    assert stats["total_nodes"] == 10
    assert stats["total_edges"] >= 15
    assert stats["blocked_edges"] == 0


def test_find_shortest_route_with_instructions(service):
    res = service.find_shortest_route("Main Gate", "Central Library", log_history=True)
    assert res["found"] is True
    assert res["path"] == ["Main Gate", "Admin Block", "Central Library"]
    assert res["total_distance"] == 260.0  # 120 + 140
    assert res["edges_count"] == 2
    assert res["estimated_time_mins"] is not None
    assert len(res["instructions"]) == 2
    assert res["instructions"][0]["from_node"] == "Main Gate"
    assert res["instructions"][0]["to_node"] == "Admin Block"


def test_route_updates_after_blocking_connection(service):
    # Baseline: Main Gate -> Central Library goes via Admin Block (260m)
    # Now block Admin Block <-> Central Library
    service.toggle_connection_blocked("Admin Block", "Central Library", True)

    stats = service.graph.get_summary_stats()
    assert stats["blocked_edges"] == 1

    # Alternative route calculation
    res = service.find_shortest_route("Main Gate", "Central Library", log_history=False)
    assert res["found"] is True
    # The route must NOT contain the segment Admin Block -> Central Library
    for i in range(len(res["path"]) - 1):
        assert not (res["path"][i] == "Admin Block" and res["path"][i + 1] == "Central Library")
        assert not (res["path"][i] == "Central Library" and res["path"][i + 1] == "Admin Block")


def test_dynamic_graph_mutation_affects_routing(service):
    # Add a shortcut location and connections:
    # "Express Tunnel": Main Gate <-> Express Tunnel (20m) <-> Central Library (30m) = 50m
    service.add_location("Express Tunnel", "Utility & Support", 30.0, 30.0, "Subterranean walkway")
    service.add_connection("Main Gate", "Express Tunnel", 20.0)
    service.add_connection("Express Tunnel", "Central Library", 30.0)

    res = service.find_shortest_route("Main Gate", "Central Library", log_history=False)
    assert res["found"] is True
    assert res["path"] == ["Main Gate", "Express Tunnel", "Central Library"]
    assert res["total_distance"] == 50.0

    # Delete shortcut location
    service.delete_location("Express Tunnel")
    assert not service.graph.has_node("Express Tunnel")

    # Route falls back to standard pathways
    res_after = service.find_shortest_route("Main Gate", "Central Library", log_history=False)
    assert res_after["found"] is True
    assert "Express Tunnel" not in res_after["path"]


def test_dashboard_metrics(service):
    dash = service.get_dashboard_summary()
    assert dash["total_locations"] == 10
    assert dash["total_connections"] >= 15
    assert "Main Gate" in dash["location_names"]
    assert "Academic" in dash["category_distribution"]
