"""
Unit tests for CampusGraph data structure module.
Tests node operations, edge operations, validations, and blocked edge handling.
"""

import pytest
from graph import CampusGraph


def test_add_and_get_nodes():
    g = CampusGraph()
    g.add_node("Main Gate", "Transport", 10.0, 10.0, "Entrance")
    g.add_node("Library", "Academic", 50.0, 50.0, "Central Library")

    assert g.has_node("Main Gate")
    assert g.has_node("Library")
    assert not g.has_node("Gym")
    assert len(g.get_nodes()) == 2
    assert g.get_node_names() == ["Library", "Main Gate"]


def test_node_validation_duplicate_and_empty():
    g = CampusGraph()
    with pytest.raises(ValueError, match="Location name cannot be empty"):
        g.add_node("   ")

    g.add_node("Admin Block")
    with pytest.raises(ValueError, match="already exists"):
        g.add_node("Admin Block")


def test_add_edge_and_get_neighbors():
    g = CampusGraph()
    g.add_node("A")
    g.add_node("B")
    g.add_edge("A", "B", 120.0)

    assert g.has_edge("A", "B")
    assert g.has_edge("B", "A")
    assert g.get_edge_distance("A", "B") == 120.0
    assert g.get_neighbors("A") == {"B": 120.0}
    assert g.get_neighbors("B") == {"A": 120.0}


def test_edge_validations():
    g = CampusGraph()
    g.add_node("A")
    g.add_node("B")

    # Missing node
    with pytest.raises(ValueError, match="does not exist"):
        g.add_edge("A", "NonExistent", 50.0)

    # Self loop
    with pytest.raises(ValueError, match="Self-loops are not allowed"):
        g.add_edge("A", "A", 50.0)

    # Zero or negative distance
    with pytest.raises(ValueError, match="Distance must be strictly positive"):
        g.add_edge("A", "B", 0.0)
    with pytest.raises(ValueError, match="Distance must be strictly positive"):
        g.add_edge("A", "B", -15.0)

    # Duplicate edge
    g.add_edge("A", "B", 100.0)
    with pytest.raises(ValueError, match="already exists"):
        g.add_edge("A", "B", 150.0)
    with pytest.raises(ValueError, match="already exists"):
        g.add_edge("B", "A", 150.0)


def test_remove_node_cascades_to_edges():
    g = CampusGraph()
    g.add_node("A")
    g.add_node("B")
    g.add_node("C")
    g.add_edge("A", "B", 50.0)
    g.add_edge("B", "C", 75.0)

    g.remove_node("B")
    assert not g.has_node("B")
    assert not g.has_edge("A", "B")
    assert not g.has_edge("B", "C")
    assert g.get_neighbors("A") == {}
    assert g.get_neighbors("C") == {}


def test_blocked_edge_handling():
    g = CampusGraph()
    g.add_node("A")
    g.add_node("B")
    g.add_edge("A", "B", 100.0, is_blocked=False)

    assert not g.is_edge_blocked("A", "B")
    assert "B" in g.get_neighbors("A", include_blocked=False)

    # Block edge
    g.set_edge_blocked("A", "B", True)
    assert g.is_edge_blocked("A", "B")
    assert g.is_edge_blocked("B", "A")
    assert "B" not in g.get_neighbors("A", include_blocked=False)
    assert "B" in g.get_neighbors("A", include_blocked=True)

    # Unblock edge
    g.set_edge_blocked("A", "B", False)
    assert not g.is_edge_blocked("A", "B")
    assert "B" in g.get_neighbors("A", include_blocked=False)
