"""
Unit tests for CampusDatabase module.
Tests SQLite persistence, constraints, foreign keys, transactions, and seeding.
"""

import pytest
from database import CampusDatabase


@pytest.fixture
def temp_db(tmp_path):
    """Creates a temporary SQLite database for isolated test execution."""
    db_file = tmp_path / "test_campus.db"
    return CampusDatabase(db_path=db_file)


def test_db_initialization(temp_db):
    locs = temp_db.get_all_locations()
    conns = temp_db.get_all_connections()
    assert len(locs) == 0
    assert len(conns) == 0


def test_location_crud_and_persistence(temp_db, tmp_path):
    # Add
    loc_id = temp_db.add_location("Gate 1", "Transport", 10.0, 10.0, "North entrance")
    assert loc_id > 0

    loc = temp_db.get_location_by_name("Gate 1")
    assert loc is not None
    assert loc["name"] == "Gate 1"
    assert loc["category"] == "Transport"

    # Update
    temp_db.update_location("Gate 1", new_name="North Gate", category="Parking & Transport")
    assert temp_db.get_location_by_name("Gate 1") is None
    updated = temp_db.get_location_by_name("North Gate")
    assert updated["category"] == "Parking & Transport"

    # Persistence verification: open another connection to the same file
    db_reopened = CampusDatabase(db_path=tmp_path / "test_campus.db")
    reopened_loc = db_reopened.get_location_by_name("North Gate")
    assert reopened_loc is not None
    assert reopened_loc["name"] == "North Gate"

    # Delete
    temp_db.delete_location("North Gate")
    assert temp_db.get_location_by_name("North Gate") is None


def test_connection_constraints_and_validation(temp_db):
    temp_db.add_location("A")
    temp_db.add_location("B")

    # Valid addition
    conn_id = temp_db.add_connection("A", "B", 150.0)
    assert conn_id > 0

    # Self-loop rejection
    with pytest.raises(ValueError, match="same location"):
        temp_db.add_connection("A", "A", 100.0)

    # Zero or negative distance rejection
    with pytest.raises(ValueError, match="positive"):
        temp_db.add_connection("A", "B", 0.0)
    with pytest.raises(ValueError, match="positive"):
        temp_db.add_connection("A", "B", -50.0)

    # Missing location rejection
    with pytest.raises(ValueError, match="does not exist"):
        temp_db.add_connection("A", "NonExistent", 100.0)

    # Duplicate connection rejection (SQLite UNIQUE constraint)
    with pytest.raises(Exception):
        temp_db.add_connection("A", "B", 200.0)
    with pytest.raises(Exception):
        temp_db.add_connection("B", "A", 200.0)


def test_connection_blocking_and_updates(temp_db):
    temp_db.add_location("X")
    temp_db.add_location("Y")
    temp_db.add_connection("X", "Y", 80.0, is_blocked=False)

    conns = temp_db.get_all_connections()
    assert len(conns) == 1
    assert conns[0]["is_blocked"] is False

    # Block connection
    temp_db.set_connection_blocked("X", "Y", True)
    conns_after = temp_db.get_all_connections()
    assert conns_after[0]["is_blocked"] is True

    # Update distance
    temp_db.update_connection("X", "Y", distance=95.0)
    conns_updated = temp_db.get_all_connections()
    assert conns_updated[0]["distance"] == 95.0


def test_seed_sample_campus(temp_db):
    temp_db.seed_sample_campus()
    locs = temp_db.get_all_locations()
    conns = temp_db.get_all_connections()

    assert len(locs) == 10
    assert len(conns) >= 15
    # Verify canonical landmarks exist
    loc_names = {l["name"] for l in locs}
    assert "Main Gate" in loc_names
    assert "Admin Block" in loc_names
    assert "Central Library" in loc_names
    assert "Campus Canteen" in loc_names


def test_search_history_logging(temp_db):
    temp_db.log_search(
        start_location="Main Gate",
        destination_location="Central Library",
        algorithm="Dijkstra",
        distance=260.0,
        edges_count=2,
        path_taken=["Main Gate", "Admin Block", "Central Library"],
        execution_time_us=120.5
    )

    history = temp_db.get_recent_searches(limit=10)
    assert len(history) == 1
    assert history[0]["start_location"] == "Main Gate"
    assert history[0]["destination_location"] == "Central Library"
    assert "Admin Block" in history[0]["path_taken"]

    temp_db.clear_search_history()
    assert len(temp_db.get_recent_searches()) == 0
